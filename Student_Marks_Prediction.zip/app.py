
import streamlit as st
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

st.set_page_config(page_title="Student Marks Prediction System", layout="centered")

st.title("📊 Student Marks Prediction System")
st.write("Predict Final Score based on study related inputs.")

# Load Dataset
data = pd.read_csv("student_marks_dataset_200_rows.csv")

X = data.drop("final_score", axis=1)
y = data["final_score"]

# Train Model
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = LinearRegression()
model.fit(X_train, y_train)

# Model Evaluation
y_pred = model.predict(X_test)
r2 = r2_score(y_test, y_pred)
mae = mean_absolute_error(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)

st.subheader("📈 Model Performance")
st.write(f"R2 Score: {r2:.2f}")
st.write(f"MAE: {mae:.2f}")
st.write(f"MSE: {mse:.2f}")

st.subheader("🎯 Enter Student Details")

study_hours = st.number_input("Study Hours", min_value=0.0, max_value=15.0, step=0.5)
attendance = st.number_input("Attendance (%)", min_value=0.0, max_value=100.0, step=1.0)
previous_score = st.number_input("Previous Exam Score", min_value=0.0, max_value=100.0, step=1.0)
assignment_score = st.number_input("Assignment Score", min_value=0.0, max_value=100.0, step=1.0)

if st.button("Predict Final Score"):
    input_data = np.array([[study_hours, attendance, previous_score, assignment_score]])
    prediction = model.predict(input_data)
    st.success(f"Predicted Final Score: {prediction[0]:.2f}")
