# Student Marks Prediction System

## How to Run

1. Open terminal in this folder
2. Install dependencies:
   pip install -r requirements.txt
3. Run the app:
   streamlit run app.py
